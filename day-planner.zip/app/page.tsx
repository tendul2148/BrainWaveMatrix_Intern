"use client"

import { useState, useEffect } from "react"
import { Calendar } from "@/components/calendar"
import { TaskList } from "@/components/task-list"
import { AddTaskForm } from "@/components/add-task-form"
import type { Task } from "@/lib/types"

export default function Home() {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date())
  const [tasks, setTasks] = useState<Task[]>([])

  // Load tasks from localStorage on initial render
  useEffect(() => {
    const savedTasks = localStorage.getItem("planner-tasks")
    if (savedTasks) {
      setTasks(JSON.parse(savedTasks))
    }
  }, [])

  // Save tasks to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem("planner-tasks", JSON.stringify(tasks))
  }, [tasks])

  // Get tasks for the selected date
  const tasksForSelectedDate = tasks.filter(
    (task) => new Date(task.date).toDateString() === selectedDate.toDateString(),
  )

  // Add a new task
  const addTask = (task: Omit<Task, "id">) => {
    const newTask = {
      ...task,
      id: Date.now().toString(),
      date: selectedDate.toISOString(),
    }
    setTasks([...tasks, newTask])
  }

  // Delete a task
  const deleteTask = (id: string) => {
    setTasks(tasks.filter((task) => task.id !== id))
  }

  // Edit a task
  const editTask = (updatedTask: Task) => {
    setTasks(tasks.map((task) => (task.id === updatedTask.id ? updatedTask : task)))
  }

  return (
    <main className="container mx-auto p-4 max-w-5xl">
      <h1 className="text-3xl font-bold text-center mb-8">Day Planner</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          <Calendar selectedDate={selectedDate} onSelectDate={setSelectedDate} tasks={tasks} />
        </div>

        <div className="space-y-6">
          <div className="bg-card rounded-lg p-4 shadow">
            <h2 className="text-xl font-semibold mb-4">
              {selectedDate.toLocaleDateString("en-US", {
                weekday: "long",
                month: "long",
                day: "numeric",
              })}
            </h2>

            <AddTaskForm onAddTask={addTask} />
          </div>

          <div className="bg-card rounded-lg p-4 shadow">
            <h2 className="text-xl font-semibold mb-4">Tasks</h2>
            <TaskList tasks={tasksForSelectedDate} onDeleteTask={deleteTask} onEditTask={editTask} />
          </div>
        </div>
      </div>
    </main>
  )
}

