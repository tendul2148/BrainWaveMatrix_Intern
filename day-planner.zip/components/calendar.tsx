"use client"

import { useState } from "react"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import type { Task } from "@/lib/types"
import { cn } from "@/lib/utils"

interface CalendarProps {
  selectedDate: Date
  onSelectDate: (date: Date) => void
  tasks: Task[]
}

export function Calendar({ selectedDate, onSelectDate, tasks }: CalendarProps) {
  const [currentMonth, setCurrentMonth] = useState(new Date())

  // Get the first day of the month
  const firstDayOfMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), 1)

  // Get the day of the week for the first day (0-6, where 0 is Sunday)
  const firstDayOfWeek = firstDayOfMonth.getDay()

  // Get the number of days in the month
  const daysInMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 0).getDate()

  // Generate array of days for the calendar
  const days = Array.from({ length: 42 }, (_, i) => {
    const day = i - firstDayOfWeek + 1
    if (day <= 0 || day > daysInMonth) {
      return null
    }
    return new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day)
  })

  // Navigate to previous month
  const prevMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1, 1))
  }

  // Navigate to next month
  const nextMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 1))
  }

  // Check if a date has tasks
  const hasTasksOnDate = (date: Date) => {
    return tasks.some((task) => new Date(task.date).toDateString() === date.toDateString())
  }

  // Get day names
  const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]

  return (
    <div className="bg-card rounded-lg p-4 shadow">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold">
          {currentMonth.toLocaleDateString("en-US", {
            month: "long",
            year: "numeric",
          })}
        </h2>
        <div className="flex space-x-2">
          <Button variant="outline" size="icon" onClick={prevMonth}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="icon" onClick={nextMonth}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-7 gap-1">
        {dayNames.map((day) => (
          <div key={day} className="text-center font-medium py-2">
            {day}
          </div>
        ))}

        {days.map((date, index) => (
          <div
            key={index}
            className={cn(
              "aspect-square flex items-center justify-center rounded-md relative",
              date ? "cursor-pointer hover:bg-muted" : "",
            )}
            onClick={() => date && onSelectDate(date)}
          >
            {date && (
              <>
                <div
                  className={cn(
                    "h-10 w-10 rounded-full flex items-center justify-center",
                    date.toDateString() === selectedDate.toDateString()
                      ? "bg-primary text-primary-foreground"
                      : date.toDateString() === new Date().toDateString()
                        ? "border border-primary"
                        : "",
                  )}
                >
                  {date.getDate()}
                </div>
                {hasTasksOnDate(date) && <div className="absolute bottom-1 w-1 h-1 bg-primary rounded-full"></div>}
              </>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}

