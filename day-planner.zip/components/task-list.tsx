"use client"

import { useState } from "react"
import type { Task } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Trash2, Edit } from "lucide-react"
import { EditTaskForm } from "@/components/edit-task-form"

interface TaskListProps {
  tasks: Task[]
  onDeleteTask: (id: string) => void
  onEditTask: (task: Task) => void
}

export function TaskList({ tasks, onDeleteTask, onEditTask }: TaskListProps) {
  const [editingTaskId, setEditingTaskId] = useState<string | null>(null)

  // Start editing a task
  const startEditing = (taskId: string) => {
    setEditingTaskId(taskId)
  }

  // Cancel editing
  const cancelEditing = () => {
    setEditingTaskId(null)
  }

  // Save edited task
  const saveTask = (task: Task) => {
    onEditTask(task)
    setEditingTaskId(null)
  }

  if (tasks.length === 0) {
    return <p className="text-muted-foreground text-center py-4">No tasks for this day</p>
  }

  return (
    <div className="space-y-3">
      {tasks.map((task) => (
        <Card key={task.id} className="p-3">
          {editingTaskId === task.id ? (
            <EditTaskForm task={task} onSave={saveTask} onCancel={cancelEditing} />
          ) : (
            <div>
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-medium">{task.title}</h3>
                  <p className="text-sm text-muted-foreground">
                    {new Date(task.date).toLocaleTimeString([], {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </p>
                </div>
                <div className="flex space-x-1">
                  <Button variant="ghost" size="icon" onClick={() => startEditing(task.id)}>
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => onDeleteTask(task.id)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              {task.description && <p className="mt-2 text-sm">{task.description}</p>}
            </div>
          )}
        </Card>
      ))}
    </div>
  )
}

