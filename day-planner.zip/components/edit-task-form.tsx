"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import type { Task } from "@/lib/types"

interface EditTaskFormProps {
  task: Task
  onSave: (task: Task) => void
  onCancel: () => void
}

export function EditTaskForm({ task, onSave, onCancel }: EditTaskFormProps) {
  const [title, setTitle] = useState(task.title)
  const [description, setDescription] = useState(task.description || "")
  const [time, setTime] = useState(task.time || "12:00")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!title.trim()) return

    onSave({
      ...task,
      title,
      description,
      time,
    })
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-3">
      <Input placeholder="Task title" value={title} onChange={(e) => setTitle(e.target.value)} required />

      <Textarea
        placeholder="Description (optional)"
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        rows={3}
      />

      <Input type="time" value={time} onChange={(e) => setTime(e.target.value)} />

      <div className="flex justify-end space-x-2">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit">Save</Button>
      </div>
    </form>
  )
}

