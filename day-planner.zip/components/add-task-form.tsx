"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import type { Task } from "@/lib/types"
import { Plus } from "lucide-react"

interface AddTaskFormProps {
  onAddTask: (task: Omit<Task, "id">) => void
}

export function AddTaskForm({ onAddTask }: AddTaskFormProps) {
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [time, setTime] = useState("12:00")
  const [isExpanded, setIsExpanded] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!title.trim()) return

    // Create a new task
    onAddTask({
      title,
      description,
      date: new Date().toISOString(), // This will be overridden in the parent component
      time,
    })

    // Reset form
    setTitle("")
    setDescription("")
    setTime("12:00")
    setIsExpanded(false)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-3">
      {!isExpanded ? (
        <Button
          type="button"
          variant="outline"
          className="w-full flex items-center justify-center gap-2"
          onClick={() => setIsExpanded(true)}
        >
          <Plus className="h-4 w-4" />
          Add Task
        </Button>
      ) : (
        <>
          <Input placeholder="Task title" value={title} onChange={(e) => setTitle(e.target.value)} required />

          <Textarea
            placeholder="Description (optional)"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={3}
          />

          <Input type="time" value={time} onChange={(e) => setTime(e.target.value)} />

          <div className="flex justify-end space-x-2">
            <Button type="button" variant="outline" onClick={() => setIsExpanded(false)}>
              Cancel
            </Button>
            <Button type="submit">Add Task</Button>
          </div>
        </>
      )}
    </form>
  )
}

